
class ClassB extends ClassA {        

    private String hello ;

	private String getA() { 
        return hello ;
    }
    
	private void setA( String a ) { 
        hello = a ;
	}
}